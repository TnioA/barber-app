# Android emulator skins

Official Android emulator skins made by Google.
